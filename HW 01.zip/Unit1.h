//---------------------------------------------------------------------------

#ifndef Unit1H
#define Unit1H
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
//---------------------------------------------------------------------------
class TForm1 : public TForm
{
__published:	// IDE-managed Components
        TPanel *Panel1;
  TLabel *Label1;
  TButton *Button1;
  TButton *Button2;
  TButton *Button3;
  TButton *Button4;
  TTimer *Timer1;
  TLabel *Label2;
  TLabel *Label3;
  TLabel *Label4;
  void __fastcall Button1Click(TObject *Sender);
  void __fastcall Button2Click(TObject *Sender);
  void __fastcall Button3Click(TObject *Sender);
  void __fastcall Button4Click(TObject *Sender);
  void __fastcall Timer1Timer(TObject *Sender);
private:	// User declarations
public:		// User declarations
        __fastcall TForm1(TComponent* Owner);
};
//---------------------------------------------------------------------------
extern PACKAGE TForm1 *Form1;
//---------------------------------------------------------------------------
class ball{
  friend class baffle;
  friend class brick;
  private:
    TShape*circle;
    TTimer*times;
    void __fastcall timer(TObject *Sender);
    int x, y;                    //  �y���ܤƶq
    int pHeight, pWidth;
    int size, power;             //  �j�p  ���O
  public:
    ~ball();
    ball(TPanel*panel, int x, int y, int speed, int size, int power);
};


class baffle{
  friend void __fastcall TForm1::Button4Click(TObject *Sender);
  friend void __fastcall TForm1::Timer1Timer(TObject *Sender);
  friend class ball;
  friend class brick;
  private:
    TLabel*rectangle;
    TTimer*time;
    void __fastcall timed(TObject *Sender);
    int pWidth1;
    int hpBaffle;                //  �תO�ͩR��
    int mark;                    //  �תO�s��
  public:
    ~baffle();
    baffle(TPanel*panel, int mark);
};

class brick{
    friend ball;
    friend baffle;
    friend void __fastcall TForm1::Timer1Timer(TObject *Sender);
    friend void __fastcall TForm1::Button4Click(TObject *Sender);
  private:
    int hpBrick, score;          //  �j���ͩR��  ����
    TShape*square;
    TTimer*timing;
    void __fastcall timez(TObject *Sender);
  public:
    int allScore; 
    ~brick();
    brick(TPanel*panel, int x_, int y_, int color);
};
#endif
