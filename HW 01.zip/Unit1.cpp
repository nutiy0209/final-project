//---------------------------------------------------------------------------

#include <vcl.h>
#include <math.h>
#pragma hdrstop
#include <time.h>

#include "Unit1.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
ball*make[6];
baffle*block[2];
brick*strip[8][4];
int i=0, j=3, k=5;
int countBrick=0, countBall=0, countBaffle=0, countBaffle_1=0;   //  �ӧQ����
int everyScore=0;                                                //  ���ƭp��
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner)
  : TForm(Owner)
{
   srand( time(NULL) );
   block[0]=new baffle(Panel1, 0);
   block[1]=new baffle(Panel1, 1);                               
   for(int x=0;x<8;x++){                                         //  �s�y�j��
     for(int y=0;y<4;y++){
       strip[x][y]=new brick(Panel1, x*127, y*46, rand()%10);
     }
   }
}


ball::~ball(){
  times->~TTimer();
  circle->~TShape();
}

ball::ball(TPanel*panel, int x, int y, int speed, int size, int power){
  circle=new TShape(panel);       //  �A���̩�n�ͦ����e��
  circle->Parent=panel;           //  �ͦ��i������
  this->x=x;
  this->y=y;
  this->power=power;
  circle->Left=250;
  circle->Top=500;
  circle->Width=size;
  circle->Height=size;
  circle->Shape=stCircle;         //  �էΪ�
  circle->Brush->Color=(TColor)random(0xffffff);
  times=new TTimer(panel);
  times->Interval=speed;           //  �C���t��
  times->Enabled=true;
  times->OnTimer=timer;            //  �ƥ�禡�W��
  pHeight=panel->Height;
  pWidth=panel->Width;
}

void __fastcall ball::timer(TObject *Sender){
  /*========����========*/
  circle->Left=circle->Left + x;
  circle->Top=circle->Top + y;
  int center_x=circle->Left + (circle->Width/2);
  int center_y=circle->Top + (circle->Height/2);
  /*========�̹��I��========*/
  if(circle->Top <= 0){    //  �̹��W��
    y=-y;
  }
  if(circle->Left + circle->Width >= pWidth || circle->Left <= 0 ){    //  �̹����k
    x=-x;
  }
  /*========�ת��I��========*/
  for(int i=0;i<2;i++){
    if(block[i] != NULL){
      if(circle->Top + circle->Height >= block[i]->rectangle->Top
         && circle->Left + circle->Width >= block[i]->rectangle->Left
         && circle->Left <= (block[i]->rectangle->Left + block[i]->rectangle->Width)){    //  �תO�W��
        y=-y;
        block[i]->hpBaffle=block[i]->hpBaffle - power;
      }
      if(sqrt(pow(center_x - block[i]->rectangle->Left,2))<= circle->Width/2
         && (center_y >= block[i]->rectangle->Top
         && center_y <= block[i]->rectangle->Top + block[i]->rectangle->Height)){    //  �תO����
        x=-x;
        y=-y;
        block[i]->hpBaffle=block[i]->hpBaffle - power;
      }
      if(sqrt(pow(center_x - (block[i]->rectangle->Left + block[i]->rectangle->Width),2))<= circle->Width/2
         && (center_y >= block[i]->rectangle->Top && center_y <= block[i]->rectangle->Top + block[i]->rectangle->Height)){    //  �תO�k��
        x=-x;
        y=-y;
        block[i]->hpBaffle=block[i]->hpBaffle - power;
      }
      if((center_x>block[i]->rectangle->Left&&(center_x<block[i]->rectangle->Left + block[i]->rectangle->Width))
        &&(center_y >= block[i]->rectangle->Top && center_y <= block[i]->rectangle->Top + block[i]->rectangle->Height)){    //  �תO�d���ɰ{�{�ܤ���
        circle->Left=block[i]->rectangle->Left+120;
        circle->Top=block[i]->rectangle->Top-circle->Height;
        circle->Left+=x;
        circle->Top+=y;
        block[i]->hpBaffle=block[i]->hpBaffle - power;
      }
      if(sqrt(pow(center_x - block[i]->rectangle->Left,2) + pow(center_y - block[i]->rectangle->Top,2)) <= circle->Width/2){    //  �תO���W�I
        x=-x;
        y=-y;
        block[i]->hpBaffle=block[i]->hpBaffle - power;
      }
      if(sqrt(pow(center_x - (block[i]->rectangle->Left + block[i]->rectangle->Width),2) + pow(center_y - block[i]->rectangle->Top,2)) <= circle->Width/2){   //  �תO�k�W�I
        x=-x;
        y=-y;
        block[i]->hpBaffle=block[i]->hpBaffle - power;
      }
      if(block[i]->hpBaffle <= 0){
        block[i]->~baffle();
        block[i]=NULL;
        if(block[0]==NULL){
          countBaffle=1;
        }
        if(block[1]==NULL){
          countBaffle_1=1;
        }
      }
    }
  }
  /*========�y��I��========*/
  for(int j=0;j<6;j++){
    if(make[j] != NULL){    //  �ϥβ���w�z
      int make_x=(make[j]->circle->Left + (make[j]->circle->Width/2));
      int make_y=(make[j]->circle->Top + (make[j]->circle->Height/2));
      if(make_x == center_x && make_y == center_y){
        continue;
      }
      if((sqrt(pow(make_x-center_x,2)+pow(make_y-center_y,2)) <= ((circle->Width/2) + (make[j]->circle->Width/2)))){
      x=-x;
      y=-y;
      }
    }
  }
  for(int j=0;j<6;j++){
    if(make[j] != NULL){
      if(make[j]->circle->Top + make[j]->circle->Height >= pHeight + 100){
        make[j]->~ball();
        make[j]=NULL;
        countBall++;
      }
    }
  }
  /*========�j���I��========*/
  
  for(int m=0;m<8;m++){
    for(int n=0;n<4;n++){
      if(strip[m][n]->hpBrick > 0){
        if(circle->Top < strip[m][n]->square->Top
          && circle->Left + circle->Width >= strip[m][n]->square->Left
          && circle->Left <= (strip[m][n]->square->Left + strip[m][n]->square->Width)){   //  �j���W��
          y=-y;
          strip[m][n]->hpBrick=strip[m][n]->hpBrick - power;
        }
        if(circle->Top < strip[m][n]->square->Top + strip[m][n]->square->Height
          && circle->Left + circle->Width >= strip[m][n]->square->Left
          && circle->Left <= (strip[m][n]->square->Left + strip[m][n]->square->Width)){   //  �j���U��
          y=-y;
          strip[m][n]->hpBrick=strip[m][n]->hpBrick - power;
        }
        if(sqrt(pow(center_x - strip[m][n]->square->Left,2))<= circle->Width/2
           && (center_y >= strip[m][n]->square->Top && center_y <= strip[m][n]->square->Top + strip[m][n]->square->Height)){    //  �j������
          x=-x;
          y=-y;
          strip[m][n]->hpBrick=strip[m][n]->hpBrick - power;
        }
        if(sqrt(pow(center_x - (strip[m][n]->square->Left + strip[m][n]->square->Width),2))<= circle->Width/2
           && (center_y >= strip[m][n]->square->Top && center_y <= strip[m][n]->square->Top + strip[m][n]->square->Height)){    //  �j���k��
          x=-x;
          y=-y;
          strip[m][n]->hpBrick=strip[m][n]->hpBrick - power;
        }
        if((center_x >= strip[m][n]->square->Left && (center_x <= strip[m][n]->square->Left + strip[m][n]->square->Width))
          &&(  center_y < strip[m][n]->square->Top + strip[m][n]->square->Height)){   //  //  �j���d���ɰ{�{
          circle->Left=strip[m][n]->square->Left+(strip[m][n]->square->Width/2);
          circle->Top=strip[m][n]->square->Top+circle->Height+25;
          circle->Left+=x;
          circle->Top+=y;
          strip[m][n]->hpBrick=strip[m][n]->hpBrick - power;
        }
        if(sqrt(pow(center_x - strip[m][n]->square->Left,2) + pow(center_y - strip[m][n]->square->Top,2)) <= circle->Width/2){    //  �j�������I
          x=-x;
          y=-y;
          strip[m][n]->hpBrick=strip[m][n]->hpBrick - power;
        }
        if(sqrt(pow(center_x - (strip[m][n]->square->Left + strip[m][n]->square->Width),2) + pow(center_y - strip[m][n]->square->Top,2)) <= circle->Width/2){   //  �j���k���I
          x=-x;
          y=-y;
          strip[m][n]->hpBrick=strip[m][n]->hpBrick - power;
        }
      }
    }
  }
}
baffle::~baffle(){
  time->~TTimer();
  rectangle->~TLabel();
}
baffle::baffle(TPanel*panel, int mark){
  rectangle=new TLabel(panel);
  rectangle->Parent=panel;
  if(mark==0){
    rectangle->Left=184;
    rectangle->Top=610;
  }else{
     rectangle->Left=600;
     rectangle->Top=610;
   }
  rectangle->Height=33;
  rectangle->Width=241;
  if(mark==0){
    rectangle->Color=clRed;
  }else{
     rectangle->Color=clWhite;
   }
  time=new TTimer(panel);
  time->Interval=30;
  time->Enabled=true;
  time->OnTimer=timed;
  pWidth1=panel->Width;
  hpBaffle=180;
  this->mark=mark;
}

void __fastcall baffle::timed(TObject *Sender){
  if(block != NULL){
    if(mark==0){    //  ��V�䲾��
      if(rectangle->Left>=0){
        if(GetAsyncKeyState(37) & 0x8000){
          rectangle->Left=rectangle->Left - 20;
        }
      }
      if(rectangle->Left + rectangle->Width <= pWidth1){
        if(GetAsyncKeyState(39) & 0x8000){
          rectangle->Left=rectangle->Left + 20;
        }
      }
    }else{          //  AD�䲾��
       if(rectangle->Left>=1){
         if(GetAsyncKeyState(65) & 0x8000){
           rectangle->Left=rectangle->Left - 20;
         }
       }
       if(rectangle->Left + rectangle->Width <= pWidth1){
         if(GetAsyncKeyState(68) & 0x8000){
           rectangle->Left=rectangle->Left + 20;
         }
       }
     }
  }
}
brick::brick(TPanel*panel, int x_, int y_, int color){
  allScore=0;
  square=new TShape(panel);
  square->Parent=panel;
  square->Left=x_;
  square->Top=y_;
  square->Width=125;
  square->Height=45;
  if(color==1){
    square->Brush->Color=TColor(255215);
    hpBrick=8;
    score=10;
  }else if(color==2 || color==3){
     square->Brush->Color=clSilver;
     hpBrick=5;
     score=8;
   }else if(color==4 || color==5 || color==6){
      square->Brush->Color=clHotLight;
      hpBrick=3;
      score=3;
    }else{
       square->Brush->Color=clMaroon;
       hpBrick=1;
       score=1;
     }
  timing=new TTimer(panel);
  timing->Interval=30;
  timing->Enabled=true;
  timing->OnTimer=timez;
}
void __fastcall brick::timez(TObject *Sender){
  if(hpBrick <= 0){
    square->Width=25;
    square->Shape=stEllipse;
    square->Top+=2;
  }
  for(int i=0;i<2;i++){
    if(block[i] != NULL){
      if(square->Top + square->Height >= block[i]->rectangle->Top
        && square->Top + square->Height <= block[i]->rectangle->Top + block[i]->rectangle->Height
        && square->Left + square->Width >= block[i]->rectangle->Left
        && square->Left <= (block[i]->rectangle->Left + block[i]->rectangle->Width)){
        square->Top+=200;
        allScore=score;
      }
    }
  }
}
brick::~brick(){
   timing->~TTimer();
   square->~TShape();
}

//---------------------------------------------------------------------------
void __fastcall TForm1::Button1Click(TObject *Sender)
{
  if(i<3){
    make[i]=new ball(Panel1, 10, 10, 40, 45, 1);
    i++;
  }
}
//---------------------------------------------------------------------------
void __fastcall TForm1::Button2Click(TObject *Sender)
{
   if(j<5 && j>2){
    make[j]=new ball(Panel1, 10, 10, 20, 30, 2);
    j++;
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button3Click(TObject *Sender)
{
  if(k==5){
    make[j]=new ball(Panel1, 10, 10, 12, 20, 10);
    k++;
  }
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Button4Click(TObject *Sender)
{
  srand( time(NULL) );
  for(int i=0;i<6;i++){
    make[i]->~ball();
  }
  for(int x=0;x<8;x++){
    for(int y=0;y<4;y++){
      strip[x][y]->~brick();
      strip[x][y]=new brick(Panel1, x*127, y*46, rand()%10);
    }
  }
  block[0]->~baffle();
  block[1]->~baffle();
  block[0]=new baffle(Panel1, 0);
  block[1]=new baffle(Panel1, 1);
  Timer1->Enabled=true;
  Button1->Enabled=true;
  Button2->Enabled=true;
  Button3->Enabled=true;
  i=0;j=3;k=5;
  countBrick=0;
  countBall=0;
  countBaffle=0;
  countBaffle_1=0;
  everyScore=0;
}
//---------------------------------------------------------------------------

void __fastcall TForm1::Timer1Timer(TObject *Sender)
{
  everyScore=0;
  countBrick=0;
  for(int x=0;x<8;x++){
     for(int y=0;y<4;y++){
        if(strip[x][y]->hpBrick <= 0){
          countBrick++;
          everyScore+=strip[x][y]->allScore;
        }
     }
  }
  Label2->Caption="����:" + String(everyScore);
  if(block[0] != NULL){
    Label3->Caption="����תO�ͩR��:\n" + String(block[0]->hpBaffle);
  }
  if(block[1] != NULL){
    Label4->Caption="�զ�תO�ͩR��:\n" + String(block[1]->hpBaffle);
  }
  /*========�ӧQ�P�_========*/
  if(countBrick == 32){
    Timer1->Enabled=false;
    ShowMessage("�C���ӧQ");
    Button1->Enabled=false;
    Button2->Enabled=false;
    Button3->Enabled=false;
  }else if(countBall==6 || (countBaffle==1 && countBaffle_1 == 1)){
     Timer1->Enabled=false;
     ShowMessage("�C������");
     Label3->Caption="����תO�ͩR��:\n 0";
     Label4->Caption="�զ�תO�ͩR��:\n 0";
     Button1->Enabled=false;
     Button2->Enabled=false;
     Button3->Enabled=false;
   }
}          
//---------------------------------------------------------------------------

